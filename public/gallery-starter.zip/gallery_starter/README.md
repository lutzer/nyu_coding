# Gallery Starter

A small static website — the completed gallery from Chapter 1.

## Run it

Open `index.html` in your browser, or (recommended) serve it with a
local dev server from VS Code:

```
npx live-server
```

It will open your browser automatically and reload the page every
time you save a file.

## Files

- `index.html` — the page markup
- `styles.css` — all the styling
- `logo.svg` — the gallery logo
- `images/` — the artwork and hero images
